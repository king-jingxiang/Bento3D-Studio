import { create } from 'zustand';
import {
  DEFAULT_GRID,
  DEFAULT_ORGANIZER,
  DEFAULT_PARAMS,
  LIMITS,
  clamp,
  isOutlineShape,
  type AppMode,
  type BoxOptions,
  type ChamferOptions,
  type FingerPullOptions,
  type GridState,
  type LabelOptions,
  type LayerConfig,
  type OrganizerConfig,
  type Params,
  type ViewTab,
  type WallOptions,
} from './types';
import {
  addColumn,
  addRow,
  evenGrid,
  mergeCells,
  removeColumnBoundary,
  removeRowBoundary,
  sanitizeGrid,
  splitCell,
  type ResolvedCell,
} from './lib/grid';
import { sanitizeOrganizer } from './lib/organizer';
import type { BentoConfig } from './lib/config';

const clampParams = (params: Params): Params => {
  const width = clamp(params.width, LIMITS.width[0], LIMITS.width[1]);
  const depth = clamp(params.depth, LIMITS.depth[0], LIMITS.depth[1]);
  const height = clamp(params.height, LIMITS.height[0], LIMITS.height[1]);
  const thickness = clamp(
    params.thickness,
    LIMITS.thickness[0],
    Math.min(LIMITS.thickness[1], Math.min(width, depth) / 6),
  );
  const fillet = clamp(
    params.fillet,
    0,
    Math.min(LIMITS.fillet[1], Math.min(width, depth) / 2 - thickness - 0.5),
  );
  const partitionHeight = clamp(
    params.partitionHeight,
    thickness + 1,
    Math.max(thickness + 1.5, height - 0.6),
  );
  const holeSize = clamp(
    params.wall.holeSize,
    LIMITS.holeSize[0],
    Math.min(LIMITS.holeSize[1], Math.max(LIMITS.holeSize[0], height - 7)),
  );
  const fingerWidth = clamp(
    params.fingerPull.width,
    LIMITS.fingerWidth[0],
    Math.min(LIMITS.fingerWidth[1], Math.max(12, width - 12)),
  );
  const fingerHeight = clamp(
    params.fingerPull.height,
    LIMITS.fingerHeight[0],
    Math.min(LIMITS.fingerHeight[1], Math.max(7, height - 2)),
  );
  const chamferSize = clamp(
    params.chamfer.size,
    LIMITS.chamfer[0],
    Math.min(LIMITS.chamfer[1], Math.max(LIMITS.chamfer[0], thickness * 0.6)),
  );
  return {
    ...params,
    width,
    depth,
    height,
    thickness,
    fillet,
    partitionHeight,
    chamfer: { ...params.chamfer, size: chamferSize },
    wall: { ...params.wall, holeSize },
    fingerPull: { ...params.fingerPull, width: fingerWidth, height: fingerHeight },
    box: {
      ...params.box,
      trayCount: Math.round(clamp(params.box.trayCount, LIMITS.trayCount[0], LIMITS.trayCount[1])),
      clearance: clamp(params.box.clearance, LIMITS.clearance[0], LIMITS.clearance[1]),
    },
  };
};

const clampLayer = (layer: LayerConfig): LayerConfig => ({
  ...layer,
  name: (layer.name ?? '').slice(0, 24),
  depth: clamp(layer.depth, LIMITS.layerDepth[0], LIMITS.layerDepth[1]),
  height: clamp(layer.height, LIMITS.layerHeight[0], LIMITS.layerHeight[1]),
  shape: isOutlineShape(layer.shape) ? layer.shape : 'rounded',
  grid: sanitizeGrid(layer.grid),
});

interface AppState {
  mode: AppMode;
  tab: ViewTab;
  params: Params;
  grid: GridState;
  organizer: OrganizerConfig;
  activeLayerId: string;
  explode: number;
  selectedCells: string[];
  setMode: (mode: AppMode) => void;
  setTab: (tab: ViewTab) => void;
  setExplode: (value: number) => void;
  reset: () => void;
  setSize: (axis: 'width' | 'depth' | 'height', value: number) => void;
  setThickness: (value: number) => void;
  setFillet: (value: number) => void;
  setPartitionHeight: (value: number) => void;
  setStackable: (value: boolean) => void;
  updateChamfer: (patch: Partial<ChamferOptions>) => void;
  updateWall: (patch: Partial<WallOptions>) => void;
  updateLabel: (patch: Partial<LabelOptions>) => void;
  updateFingerPull: (patch: Partial<FingerPullOptions>) => void;
  updateBox: (patch: Partial<BoxOptions>) => void;
  setGrid: (grid: GridState) => void;
  setPreset: (cols: number, rows: number) => void;
  addGridColumn: () => void;
  addGridRow: () => void;
  removeGridColumnBoundary: (boundary: number) => void;
  removeGridRowBoundary: (boundary: number) => void;
  mergeSelectedCells: (cells: ResolvedCell[]) => void;
  splitGridCell: (cell: ResolvedCell) => void;
  setSelectedCells: (ids: string[]) => void;
  setActiveLayer: (id: string) => void;
  addOrganizerLayer: () => void;
  removeOrganizerLayer: (id: string) => void;
  moveOrganizerLayer: (id: string, direction: -1 | 1) => void;
  updateOrganizerLayer: (
    id: string,
    patch: Partial<Pick<LayerConfig, 'name' | 'depth' | 'height' | 'shape' | 'grid'>>,
  ) => void;
  updateOrganizer: (patch: Partial<Pick<OrganizerConfig, 'align' | 'dividerInset'>>) => void;
  applyConfig: (config: BentoConfig) => void;
}

function activeLayer(state: AppState): LayerConfig {
  return (
    state.organizer.layers.find((layer) => layer.id === state.activeLayerId) ??
    state.organizer.layers[0]
  );
}

function currentGrid(state: AppState): GridState {
  return state.mode === 'organizer' ? activeLayer(state).grid : state.grid;
}

function routeGrid(
  state: AppState,
  next: GridState,
  clearSelection: boolean,
): Partial<AppState> {
  const grid = sanitizeGrid(next);
  const base = clearSelection ? { selectedCells: [] as string[] } : {};
  if (state.mode === 'organizer') {
    const id = activeLayer(state).id;
    return {
      ...base,
      organizer: {
        ...state.organizer,
        layers: state.organizer.layers.map((layer) =>
          layer.id === id ? { ...layer, grid } : layer,
        ),
      },
    };
  }
  return { ...base, grid };
}

const initialOrganizer = sanitizeOrganizer(DEFAULT_ORGANIZER);

export const useAppStore = create<AppState>((set) => ({
  mode: 'tray',
  tab: 'size',
  params: DEFAULT_PARAMS,
  grid: DEFAULT_GRID,
  organizer: initialOrganizer,
  activeLayerId: initialOrganizer.layers[0].id,
  explode: 0.35,
  selectedCells: [],
  setMode: (mode) => set({ mode, selectedCells: [] }),
  setTab: (tab) => set({ tab }),
  setExplode: (value) => set({ explode: clamp(value, 0, 1) }),
  reset: () =>
    set(() => {
      const organizer = sanitizeOrganizer(DEFAULT_ORGANIZER);
      return {
        params: DEFAULT_PARAMS,
        grid: DEFAULT_GRID,
        organizer,
        activeLayerId: organizer.layers[0].id,
        selectedCells: [],
        explode: 0.35,
      };
    }),
  setSize: (axis, value) =>
    set((state) => {
      const limits =
        axis === 'width' ? LIMITS.width : axis === 'depth' ? LIMITS.depth : LIMITS.height;
      const next = { ...state.params, [axis]: clamp(value, limits[0], limits[1]) } as Params;
      if (axis === 'height') {
        next.partitionHeight = clamp(
          next.height - next.thickness * 2,
          next.thickness + 1,
          next.height - 0.6,
        );
      }
      return { params: clampParams(next) };
    }),
  setThickness: (value) =>
    set((state) => ({ params: clampParams({ ...state.params, thickness: value }) })),
  setFillet: (value) =>
    set((state) => ({ params: clampParams({ ...state.params, fillet: value }) })),
  setPartitionHeight: (value) =>
    set((state) => ({ params: clampParams({ ...state.params, partitionHeight: value }) })),
  setStackable: (value) =>
    set((state) => ({ params: clampParams({ ...state.params, stackable: value }) })),
  updateChamfer: (patch) =>
    set((state) => ({
      params: clampParams({ ...state.params, chamfer: { ...state.params.chamfer, ...patch } }),
    })),
  updateWall: (patch) =>
    set((state) => ({
      params: clampParams({ ...state.params, wall: { ...state.params.wall, ...patch } }),
    })),
  updateLabel: (patch) =>
    set((state) => ({
      params: clampParams({ ...state.params, label: { ...state.params.label, ...patch } }),
    })),
  updateFingerPull: (patch) =>
    set((state) => ({
      params: clampParams({
        ...state.params,
        fingerPull: { ...state.params.fingerPull, ...patch },
      }),
    })),
  updateBox: (patch) =>
    set((state) => ({
      params: clampParams({ ...state.params, box: { ...state.params.box, ...patch } }),
    })),
  setGrid: (grid) => set((state) => routeGrid(state, grid, false)),
  setPreset: (cols, rows) => set((state) => routeGrid(state, evenGrid(cols, rows), true)),
  addGridColumn: () => set((state) => routeGrid(state, addColumn(currentGrid(state)), true)),
  addGridRow: () => set((state) => routeGrid(state, addRow(currentGrid(state)), true)),
  removeGridColumnBoundary: (boundary) =>
    set((state) => routeGrid(state, removeColumnBoundary(currentGrid(state), boundary), true)),
  removeGridRowBoundary: (boundary) =>
    set((state) => routeGrid(state, removeRowBoundary(currentGrid(state), boundary), true)),
  mergeSelectedCells: (cells) =>
    set((state) => routeGrid(state, mergeCells(currentGrid(state), cells), true)),
  splitGridCell: (cell) =>
    set((state) => routeGrid(state, splitCell(currentGrid(state), cell), true)),
  setSelectedCells: (ids) => set({ selectedCells: ids }),
  setActiveLayer: (id) =>
    set((state) =>
      state.organizer.layers.some((layer) => layer.id === id)
        ? { activeLayerId: id, selectedCells: [] }
        : {},
    ),
  addOrganizerLayer: () =>
    set((state) => {
      const layers = state.organizer.layers;
      if (layers.length >= LIMITS.layerCount[1]) return {};
      const last = layers[layers.length - 1];
      const id = `layer-${Date.now().toString(36)}-${layers.length + 1}`;
      const layer: LayerConfig = clampLayer({
        id,
        name: `第 ${layers.length + 1} 层`,
        depth: Math.round((last?.depth ?? 100) * 0.78),
        height: last?.height ?? 24,
        shape: last?.shape ?? 'rounded',
        grid: evenGrid(1, 1),
      });
      return {
        organizer: { ...state.organizer, layers: [...layers, layer] },
        activeLayerId: id,
        selectedCells: [],
      };
    }),
  removeOrganizerLayer: (id) =>
    set((state) => {
      const layers = state.organizer.layers;
      if (layers.length <= LIMITS.layerCount[0]) return {};
      const index = layers.findIndex((layer) => layer.id === id);
      if (index < 0) return {};
      const remaining = layers.filter((layer) => layer.id !== id);
      const nextActive =
        state.activeLayerId === id
          ? remaining[Math.min(index, remaining.length - 1)].id
          : state.activeLayerId;
      return {
        organizer: { ...state.organizer, layers: remaining },
        activeLayerId: nextActive,
        selectedCells: [],
      };
    }),
  moveOrganizerLayer: (id, direction) =>
    set((state) => {
      const layers = [...state.organizer.layers];
      const index = layers.findIndex((layer) => layer.id === id);
      const target = index + direction;
      if (index < 0 || target < 0 || target >= layers.length) return {};
      const [item] = layers.splice(index, 1);
      layers.splice(target, 0, item);
      return { organizer: { ...state.organizer, layers } };
    }),
  updateOrganizerLayer: (id, patch) =>
    set((state) => ({
      organizer: {
        ...state.organizer,
        layers: state.organizer.layers.map((layer) =>
          layer.id === id ? clampLayer({ ...layer, ...patch }) : layer,
        ),
      },
    })),
  updateOrganizer: (patch) =>
    set((state) => ({
      organizer: {
        ...state.organizer,
        ...patch,
        dividerInset:
          patch.dividerInset === undefined
            ? state.organizer.dividerInset
            : clamp(patch.dividerInset, LIMITS.dividerInset[0], LIMITS.dividerInset[1]),
      },
    })),
  applyConfig: (config) =>
    set(() => {
      const organizer = sanitizeOrganizer(config.organizer);
      return {
        mode: config.mode,
        params: clampParams(config.params),
        grid: sanitizeGrid(config.grid),
        organizer,
        activeLayerId: organizer.layers[0].id,
        selectedCells: [],
        explode: 0.35,
      };
    }),
}));
